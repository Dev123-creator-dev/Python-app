"""
run_pipeline.py  — MAIN entry point (run this).
================================================
New plan: OncoPredictor is MANUAL. This pipeline starts afterwards and does:

  STEP 1  move the manual Onco files (2358 side)  ->  a fresh per-run folder on K drive
  STEP 2  run the R clustering script on the .tab   (produces clustering + ranked CSVs)
  STEP 3  run g:Profiler on the Diffex report       (produces enrichment CSVs)

Every run gets its OWN folder; ALL files for that run live inside it.
ALL paths come from config.yaml. ALL inputs are given dynamically on the command line.

Example
-------
  python run_pipeline.py \
      --tab    "\\\\2358\\OncoOutput\\Vemurafenib_13FEB23.tab" \
      --diffex "\\\\2358\\OncoOutput\\Diffex_report.tab" \
      --compound Vemurafenib

Add --simulate to test end-to-end without R / internet.
"""

import os
import sys
import time
import argparse
import datetime
import subprocess

import yaml

import move_to_kdrive
import gprofiler_runner

BASE = os.path.dirname(os.path.abspath(__file__))


# ----------------------------------------------------------------- small logger
class Log:
    def __init__(self, run_dir):
        self.fh = open(os.path.join(run_dir, "run.log"), "w", encoding="utf-8") if run_dir else None

    def __call__(self, msg, level="INFO", stage="pipeline"):
        n = datetime.datetime.now().strftime("%H:%M:%S")
        line = f"{n}  {level:<4} {stage:<12} {msg}"
        print(line)
        if self.fh:
            self.fh.write(line + "\n"); self.fh.flush()


def load_config(path):
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def make_run_dir(cfg, compound):
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"RUN_{stamp}_{compound}"
    run_dir = os.path.join(cfg["paths"]["kdrive_output_base"], name)
    os.makedirs(run_dir, exist_ok=True)
    return name, run_dir


# ----------------------------------------------------------------- STEP 2: R
def run_clustering(cfg, tab_path, run_dir, log, simulate=False):
    out1 = os.path.join(run_dir, "clustering data.csv")
    out2 = os.path.join(run_dir, "ranked compounds.csv")
    if simulate:
        log("[simulate] Rscript run_clustering.R (.tab, run_dir)", stage="clustering")
        time.sleep(0.4)
        open(out1, "w").write("Compound,cellLineName,EC50_Nrank\nVemurafenib,HT29,0.12\n")
        open(out2, "w").write("Compound,Rank\nVemurafenib,0\nDabrafenib,1.84\n")
        log('[1] "Vemurafenib"', level="R", stage="clustering")
        log('[1] "Complete."', level="R", stage="clustering")
        return
    wrapper = os.path.join(BASE, cfg["r"]["wrapper"])
    env = dict(os.environ, CLUSTERING_SRC=cfg["paths"]["clustering_src"])
    cmd = [cfg["paths"]["rscript_exe"], wrapper, tab_path, run_dir]
    log(" ".join(cmd), stage="clustering")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=int(cfg["r"]["timeout_sec"]), env=env)
    except FileNotFoundError:
        raise RuntimeError("Rscript not found — set paths.rscript_exe in config.yaml, or use --simulate")
    for ln in (proc.stdout or "").splitlines():
        log(ln, level="R", stage="clustering")
    if proc.returncode != 0:
        for ln in (proc.stderr or "").splitlines()[-10:]:
            log(ln, level="ERR", stage="clustering")
        raise RuntimeError(f"Rscript exited with code {proc.returncode}")


# ----------------------------------------------------------------- orchestrator
def main():
    ap = argparse.ArgumentParser(description="OncoPanel post-Onco pipeline (R + g:Profiler)")
    ap.add_argument("--config", default=os.path.join(BASE, "config.yaml"))
    ap.add_argument("--tab", required=True, help="assay .tab file (from manual Onco, on 2358)")
    ap.add_argument("--diffex", required=True, help="Diffex report (from manual Onco, on 2358)")
    ap.add_argument("--mutation", help="Mutation report (optional)")
    ap.add_argument("--compound", default=None, help="run name (default: from .tab filename)")
    ap.add_argument("--simulate", action="store_true", help="fake R + g:Profiler (no R/internet needed)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    compound = args.compound or os.path.splitext(os.path.basename(args.tab))[0].split("_")[0]

    run_name, run_dir = make_run_dir(cfg, compound)
    log = Log(run_dir)
    t0 = time.time()
    log(f"=== {run_name} ===")
    log(f"run folder: {run_dir}")
    log(f"config: {args.config} · mode: {'SIMULATE' if args.simulate else 'LIVE'}")

    try:
        # STEP 1 — move manual Onco files 2358 -> K-drive run folder
        srcs = [args.tab, args.diffex] + ([args.mutation] if args.mutation else [])
        moved = move_to_kdrive.move_files(srcs, run_dir,
                                          mode=cfg.get("transfer", {}).get("mode", "copy"), log=lambda m: log(m, stage="move"))
        local_tab = os.path.join(run_dir, os.path.basename(args.tab))
        local_diffex = os.path.join(run_dir, os.path.basename(args.diffex))
        log(f"{len(moved)} file(s) staged on K drive", level="OK", stage="move")

        # STEP 2 — R clustering (writes clustering data.csv + ranked compounds.csv into run_dir)
        run_clustering(cfg, local_tab, run_dir, log, simulate=args.simulate)
        log("clustering data.csv + ranked compounds.csv", level="OK", stage="clustering")

        # STEP 3 — g:Profiler (writes sensitivity.csv + resistance.csv into run_dir)
        summary = gprofiler_runner.run_profiler(cfg["gprofiler"], local_diffex, run_dir,
                                                simulate=args.simulate, log=lambda m: log(m, stage="gprofiler"))
        log(f"enrichment done · {summary['sensitive_terms']} sens / {summary['resistant_terms']} res terms",
            level="OK", stage="gprofiler")

        # summary
        files = sorted(os.listdir(run_dir))
        log(f"COMPLETE in {time.time()-t0:.1f}s · {len(files)} files in run folder", level="OK")
        log("run folder contents: " + ", ".join(files))
        return 0
    except Exception as exc:  # surface any failure clearly and stop
        log(str(exc), level="ERR")
        log("PIPELINE FAILED — see message above", level="ERR")
        return 1


if __name__ == "__main__":
    sys.exit(main())
