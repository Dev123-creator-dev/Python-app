# OncoPanel Post-Onco Pipeline (R + g:Profiler)

**New plan:** OncoPredictor is run **manually**. This pipeline starts *after* that and does three steps, each run in its **own folder**, with **all paths in `config.yaml`** and **all inputs given dynamically** on the command line:

1. **Move** the manual Onco files (2358 side) → a fresh per-run folder on the K drive.
2. **Clustering (R)** — runs your validated `GenerateClusteringFile.R` on the `.tab` file.
3. **g:Profiler** — builds Top-60 gene lists from the Diffex report and queries the API.

## Prerequisites
- **Python 3.9+** with the packages in `requirements.txt` (`pip install -r requirements.txt`).
- **R** installed, with `dplyr`, and `Rscript` reachable (set its full path in `config.yaml`).
- The runner must be able to reach: the **K drive**, the **2358 file location** (share/UNC), the **R: support files**, and **`biit.cs.ut.ee`** (g:Profiler) over HTTPS.
- The validated `GenerateClusteringFile.R` available at the path in `config.yaml`.

## Install & run
```bash
pip install -r requirements.txt

python run_pipeline.py \
  --tab    "\\2358\OncoOutput\Vemurafenib_13FEB23.tab" \
  --diffex "\\2358\OncoOutput\Diffex_report.tab" \
  --mutation "\\2358\OncoOutput\Mutation_report.tab" \
  --compound Vemurafenib
```
Add `--simulate` to test the whole flow without R or internet (fakes those two steps).

## Files
```
onco_pipeline/
├── config.yaml          ALL paths & settings (edit this, not the code)
├── run_pipeline.py      MAIN orchestrator — run this
├── move_to_kdrive.py    STEP 1 — 2358 → K drive (separate script)
├── run_clustering.R     STEP 2 — wrapper that calls GenerateClusteringFile()
├── gprofiler_runner.py  STEP 3 — Diffex → gene lists → g:Profiler API
├── requirements.txt
└── _kdrive/Runs/RUN_<timestamp>_<compound>/   created per run; holds ALL files
```

## Dynamic inputs (CLI)
| Flag | Meaning |
|------|---------|
| `--tab` | assay `.tab` file from the manual Onco run |
| `--diffex` | Diffex report from the manual Onco run |
| `--mutation` | Mutation report (optional) |
| `--compound` | run name (default: derived from the `.tab` filename) |
| `--config` | config file path (default `config.yaml`) |
| `--simulate` | fake R + g:Profiler for testing |

## Output
Everything for a run lands in one folder, e.g. `RUN_20260810_151335_Vemurafenib/`:
input `.tab` + Diffex + Mutation, `clustering data.csv`, `ranked compounds.csv`,
`top60_sensitive.txt`, `top60_resistant.txt`, `sensitivity.csv`, `resistance.csv`, `run.log`.
