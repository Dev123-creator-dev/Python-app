# run_clustering.R — parameterised wrapper for the validated clustering function.
# Usage:  Rscript run_clustering.R <client_data_fn> <working_directory>
#
# GenerateClusteringFile() reads a GLOBAL `working_directory` (not an argument) and
# writes its two CSVs there. This wrapper sets that global, sources the UNMODIFIED
# validated script, and calls it. Point CLUSTERING_SRC at the real file via env var.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) stop("usage: Rscript run_clustering.R <client_data_fn> <working_directory>")

client_data_fn     <- args[1]
working_directory <<- args[2]        # global — the function writes outputs here

clustering_src <- Sys.getenv(
  "CLUSTERING_SRC",
  "K:/LabOperations/Oncopanel/QC support files/GenerateClusteringFile.R"
)

cat(sprintf("run_clustering: client_data_fn = %s\n", client_data_fn))
cat(sprintf("run_clustering: working_directory = %s\n", working_directory))
cat(sprintf("run_clustering: sourcing %s\n", clustering_src))

suppressMessages(library(dplyr))
source(clustering_src)
GenerateClusteringFile(client_data_fn)     # prints the compound name, then "Complete."
cat("run_clustering: done\n")
