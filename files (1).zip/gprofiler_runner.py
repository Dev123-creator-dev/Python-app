"""
gprofiler_runner.py
===================
STEP 3. Takes the Diffex report, builds the Top-N sensitive/resistant gene lists
(same logic as the Excel template: fold change < 1 = sensitive, > 1 = resistant),
sends them to the g:Profiler REST API as ORDERED queries, and writes the results.

If a query returns nothing significant, it automatically retries with all_results
(the documented "All results" fallback).
"""

import os
import csv
import json


def derive_gene_lists(diffex_path, top_n=60, sensitive_max_fc=1.0):
    """Return (top_sensitive, top_resistant) gene-name lists, in file order."""
    sens, res = [], []
    with open(diffex_path, encoding="utf-8", errors="ignore") as fh:
        header = fh.readline().rstrip("\n").split("\t")
        # locate the fold-change column (by name if possible, else column index 2)
        fc_idx = 2
        for i, h in enumerate(header):
            if h.strip().lower().replace(" ", "") in ("foldchange", "fold_change"):
                fc_idx = i
                break
        for line in fh:
            parts = line.rstrip("\n").split("\t")
            if len(parts) <= fc_idx:
                continue
            gene = parts[0].strip()
            try:
                fc = float(parts[fc_idx])
            except ValueError:
                continue
            if fc < sensitive_max_fc:
                sens.append(gene)
            elif fc > sensitive_max_fc:
                res.append(gene)
    return sens[:top_n], res[:top_n]


def _query(cfg, genes, all_results=False):
    import requests
    payload = {
        "organism": cfg.get("organism", "hsapiens"),
        "query": genes,
        "ordered": bool(cfg.get("ordered", True)),
        "all_results": all_results,
        "no_evidences": True,
    }
    resp = requests.post(cfg["api_url"], json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json().get("result", [])


def _write_csv(path, rows):
    cols = ["source", "native", "name", "p_value", "term_size", "intersection_size"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])


def run_profiler(cfg, diffex_path, out_dir, simulate=False, log=print):
    top_n = int(cfg.get("top_n", 60))
    sens, res = derive_gene_lists(diffex_path, top_n, float(cfg.get("sensitive_max_fc", 1.0)))
    # always save the gene lists that were sent (audit trail)
    open(os.path.join(out_dir, "top60_sensitive.txt"), "w").write("\n".join(sens))
    open(os.path.join(out_dir, "top60_resistant.txt"), "w").write("\n".join(res))
    log(f"gene lists: {len(sens)} sensitive, {len(res)} resistant (top {top_n})")

    sens_csv = os.path.join(out_dir, "sensitivity.csv")
    res_csv = os.path.join(out_dir, "resistance.csv")

    if simulate:
        demo = [{"source": "GO:BP", "native": f"GO:00000{i}", "name": f"demo term {i}",
                 "p_value": round(1e-3 / (i + 1), 6), "term_size": 50 + i,
                 "intersection_size": 8 - (i % 4)} for i in range(6)]
        _write_csv(sens_csv, demo)
        _write_csv(res_csv, demo[:4])
        log("sensitivity: 0 significant terms — retrying with all_results=true")
        log(f"sensitivity: {len(demo)} terms -> sensitivity.csv")
        log(f"resistance:  {len(demo[:4])} terms -> resistance.csv")
        return {"sensitive_terms": len(demo), "resistant_terms": len(demo[:4])}

    # ---- live API calls ----
    log(f"POST {cfg['api_url']} · sensitivity · ordered={cfg.get('ordered')}")
    s = _query(cfg, sens)
    if not s:
        log("sensitivity: no significant terms — retrying with all_results=true")
        s = _query(cfg, sens, all_results=True)
    _write_csv(sens_csv, s)
    log(f"sensitivity: {len(s)} terms -> sensitivity.csv")

    log(f"POST {cfg['api_url']} · resistance · ordered={cfg.get('ordered')}")
    r = _query(cfg, res)
    if not r:
        log("resistance: no significant terms — retrying with all_results=true")
        r = _query(cfg, res, all_results=True)
    _write_csv(res_csv, r)
    log(f"resistance:  {len(r)} terms -> resistance.csv")

    return {"sensitive_terms": len(s), "resistant_terms": len(r)}
