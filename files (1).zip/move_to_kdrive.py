"""
move_to_kdrive.py
=================
STEP 1 (kept as its own script, as requested).

OncoPredictor is run MANUALLY. Its output files (the assay .tab, the Diffex
report, the Mutation report) sit on the 2358 side. This module copies/moves them
into the per-run folder on the K drive so the rest of the pipeline can use them.

Can be used two ways:
  - imported:  move_files([...], dest_dir, mode="copy")
  - standalone: python move_to_kdrive.py --dest K:/.../RUN_x --files a.tab b.tab
"""

import os
import shutil
import argparse


def move_files(src_paths, dest_dir, mode="copy", log=print):
    """Copy (or move) each file in src_paths into dest_dir. Returns new paths."""
    os.makedirs(dest_dir, exist_ok=True)
    out = []
    for src in src_paths:
        if not src:
            continue
        if not os.path.exists(src):
            raise FileNotFoundError(f"source file not found on 2358 side: {src}")
        dst = os.path.join(dest_dir, os.path.basename(src))
        if mode == "move":
            shutil.move(src, dst)
        else:
            shutil.copy2(src, dst)          # copy2 preserves timestamps
        log(f"{mode:>4} : {os.path.basename(src)}  ->  {dest_dir}")
        out.append(dst)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Move manual Onco files 2358 -> K drive")
    ap.add_argument("--dest", required=True, help="destination run folder on K drive")
    ap.add_argument("--files", nargs="+", required=True, help="source files on 2358 side")
    ap.add_argument("--mode", default="copy", choices=["copy", "move"])
    a = ap.parse_args()
    moved = move_files(a.files, a.dest, a.mode)
    print(f"done: {len(moved)} file(s) in {a.dest}")
