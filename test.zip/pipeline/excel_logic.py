"""
pipeline/excel_logic.py
=======================
Reproduces the EXISTING business logic from
"Mutations_and_Hotspots_Template.xlsx" — we automate the manual copy/paste,
we do NOT change the calculations.

Decoded template logic ("Table 3 for DiffEx" tab):
  R..V  = copy of Diffex A..E  (Gene, Probe, Fold change, P-value, Q-value)
  W     = Drug Response = IF(FoldChange < 0, "Sensitive", "Resistant")
  AA    = Sensitive pool  = IF(FoldChange < 1, Gene, "")
  AB    = Resistant pool  = IF(FoldChange > 1, Gene, "")
  Y,Z   = running rank over AA/AB (turns pools into ordered 1..N lists)
  AE    = Top-60 Sensitive (ordered)   AG = Top-10 Sensitive
  AF    = Top-60 Resistant (ordered)   AH = Top-10 Resistant

"Tables 1 and 2 for Mutations" tab (Table 2 mapping):
  Gene<-A, Mutation<-I, Cell Line<-J, Cancer Type<-K, Drug Response<-L

NOTE / FLAGGED AMBIGUITY: Drug Response uses FC<0 while the pools use FC<1 / >1.
We preserve the template's literal <1 / >1 for the gene lists (they feed g:Profiler).
"""

import csv
from openpyxl import load_workbook


# ---- diffex loading (columns A..P per the real Diffex file) -----------------
DIFFEX_A_TO_P = 16  # Gene..ResistantCellLines


def _cellstr(v):
    """Normalise a cell value to a string (keep whole numbers clean)."""
    if v is None:
        return ""
    if isinstance(v, float):
        return str(int(v)) if v == int(v) else repr(v)
    return str(v).strip()


def _read_table(path):
    """
    Read a Diffex/Mutation file and return (header, rows).
    Accepts .xlsx/.xlsm (Excel), .tab/.txt/.tsv (tab-delimited), .csv (comma).
    """
    import os
    ext = os.path.splitext(path)[1].lower()

    if ext in (".xlsx", ".xlsm", ".xltx"):
        # Excel file (e.g. downloaded straight from Onco)
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active                       # first / active sheet holds the data
        header, data = None, []
        for r in ws.iter_rows(values_only=True):
            vals = [_cellstr(c) for c in r]
            if header is None:
                if all(v == "" for v in vals):
                    continue                 # skip blank leading rows
                header = vals
                continue
            if not vals or vals[0] == "":
                continue                     # stop-ish: skip rows with no gene
            data.append(vals)
        wb.close()
        header = header or []
    else:
        # text file: tab for .tab/.txt/.tsv, comma for .csv
        delim = "," if ext == ".csv" else "\t"
        header, data = [], []
        with open(path, encoding="utf-8", errors="ignore", newline="") as fh:
            reader = csv.reader(fh, delimiter=delim)
            header = [c.strip() for c in next(reader, [])]
            for r in reader:
                if r and str(r[0]).strip():
                    data.append([_cellstr(c) for c in r])

    if not header or header[0] == "":
        raise ValueError("file has no header row (is it the right file?)")
    return header, data


def load_diffex(path):
    """Read the Diffex data file (Excel or tab/csv). Returns (header, rows)."""
    return _read_table(path)


def load_mutation(path):
    """Read the Mutation data file (Excel or tab/csv). Returns (header, rows)."""
    return _read_table(path)


def validate_diffex(header):
    """Ensure the columns the logic needs are present (Gene + Fold change)."""
    low = [h.strip().lower() for h in header]
    gene_ok = any(k in low[0] for k in ("gene", "genomic")) if low else False
    if not gene_ok:
        raise ValueError(f"Required column 'Gene' not found (got '{header[0] if header else ''}')")
    # fold change is column C (index 2) in the real file
    if len(header) < 3:
        raise ValueError("Diffex file missing the Fold Change column (expected column C)")
    return True


def compute_gene_lists(header, rows, top_n=60, report_top_n=10, sensitive_max_fc=1.0, fc_idx=2, gene_idx=0):
    """Reproduce AA/AB + AE/AF/AG/AH. Returns dict of ordered gene lists."""
    sensitive, resistant = [], []
    for r in rows:
        if len(r) <= fc_idx:
            continue
        gene = r[gene_idx].strip()
        try:
            fc = float(r[fc_idx])
        except ValueError:
            continue
        if fc < sensitive_max_fc:          # AA: IF(FC<1, gene)
            sensitive.append(gene)
        elif fc > sensitive_max_fc:        # AB: IF(FC>1, gene)
            resistant.append(gene)
    return {
        "top60_sensitive": sensitive[:top_n],       # AE
        "top60_resistant": resistant[:top_n],       # AF
        "top10_sensitive": sensitive[:report_top_n],  # AG
        "top10_resistant": resistant[:report_top_n],  # AH
        "n_sensitive": len(sensitive),
        "n_resistant": len(resistant),
    }


def drug_response(fc):
    """W = IF(FoldChange < 0, 'Sensitive', 'Resistant')."""
    try:
        return "Sensitive" if float(fc) < 0 else "Resistant"
    except (ValueError, TypeError):
        return ""


# ---- populate the real template so Excel formulas recompute on open --------
def populate_template(template_path, diffex_header, diffex_rows, mutation_rows, out_path):
    """
    Write Diffex A..P into 'Table 3 for DiffEx' and mutation data into
    'Tables 1 and 2 for Mutations'. The template's own formulas (R..AH, Tables 1&2)
    recompute when opened in Excel — so the business logic stays exactly as-is.
    """
    wb = load_workbook(template_path)
    t3 = wb["Table 3 for DiffEx"]
    # paste Diffex values into A..P starting row 2 (do not touch derived columns Q+)
    for i, row in enumerate(diffex_rows, start=2):
        for j in range(min(len(row), DIFFEX_A_TO_P)):
            t3.cell(row=i, column=j + 1, value=_num(row[j]))

    if mutation_rows is not None and "Tables 1 and 2 for Mutations" in wb.sheetnames:
        mt = wb["Tables 1 and 2 for Mutations"]
        for i, row in enumerate(mutation_rows, start=2):
            for j in range(len(row)):
                mt.cell(row=i, column=j + 1, value=_num(row[j]))

    wb.save(out_path)
    return out_path


def _num(v):
    """Convert numeric-looking strings to numbers so Excel formulas work."""
    if v is None:
        return None
    s = str(v).strip()
    if s == "":
        return None
    try:
        return int(s)
    except ValueError:
        try:
            return float(s)
        except ValueError:
            return s


def report_table3(diffex_header, diffex_rows, n=60):
    """Build the report DiffEx table (R1:W61): Gene, Probe, Fold change, P-value, Q-value, Drug Response."""
    out = [["Gene", "Probe", "Fold change", "P-value", "Q-value", "Drug Response"]]
    for r in diffex_rows[:n]:
        fc = r[2] if len(r) > 2 else ""
        out.append([r[0], r[1] if len(r) > 1 else "", fc,
                    r[3] if len(r) > 3 else "", r[4] if len(r) > 4 else "", drug_response(fc)])
    return out
