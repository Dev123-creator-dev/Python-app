"""
pipeline/gprofiler_web.py
=========================
Drives the g:Profiler WEBSITE (not the API) and downloads the CSV, so the
output is byte-for-byte the website format (gene names in the intersections
column). Matches the SOP: Homo sapiens, ONLY "Ordered query" checked,
"Highlight driver terms in GO" and "Run as multiquery" unchecked.

Called by controller.py for steps 7.5.3 (sensitivity) and 7.5.4 (resistance).

Requires:  pip install selenium   (+ Google Chrome). Selenium 4.6+ auto-manages the driver.
"""

import os
import glob
import time
import shutil

URL = "https://biit.cs.ut.ee/gprofiler/gost"


def _read_genes_from_list(genes):
    seen, out = set(), []
    for g in genes:
        g = str(g).strip().strip('"').strip("'").strip()
        if g and g.lower() != "nan" and g not in seen:
            seen.add(g)
            out.append(g)
    return out


def _make_driver(download_dir, headless):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    os.makedirs(download_dir, exist_ok=True)
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--start-maximized")
    opts.add_argument("--ignore-certificate-errors")
    opts.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })
    driver = webdriver.Chrome(options=opts)
    try:
        driver.execute_cdp_cmd("Page.setDownloadBehavior",
                               {"behavior": "allow", "downloadPath": download_dir})
    except Exception:
        pass
    return driver


def _set_checkbox(driver, label_text, want_checked):
    from selenium.webdriver.common.by import By
    try:
        boxes = driver.find_elements(
            By.XPATH,
            f"//label[contains(normalize-space(.), '{label_text}')]//input[@type='checkbox'] | "
            f"//*[contains(normalize-space(.), '{label_text}')]/preceding-sibling::input[@type='checkbox'][1] | "
            f"//input[@type='checkbox'][following-sibling::*[contains(normalize-space(.), '{label_text}')]]"
        )
        for b in boxes:
            if b.is_selected() != want_checked:
                driver.execute_script("arguments[0].click();", b)
            return True
    except Exception:
        pass
    return False


def _click_first(driver, xpaths):
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    for xp in xpaths:
        try:
            el = WebDriverWait(driver, 15).until(EC.element_to_be_clickable((By.XPATH, xp)))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
            time.sleep(0.5)
            driver.execute_script("arguments[0].click();", el)
            return True
        except Exception:
            continue
    return False


def _wait_download(download_dir, before, timeout=150):
    end = time.time() + timeout
    while time.time() < end:
        files = set(glob.glob(os.path.join(download_dir, "*.csv"))) - before
        partial = glob.glob(os.path.join(download_dir, "*.crdownload"))
        if files and not partial:
            return max(files, key=os.path.getctime)
        time.sleep(1)
    return None


def run(cfg, genes, out_csv, highlight=True, simulate=False, log=print):
    """
    Same signature as the old API module so controller.py doesn't change much.
    - genes: list of gene symbols (top 60)
    - out_csv: full path to write the downloaded CSV (e.g. reports/sensitivity.csv)
    Returns a term count (best-effort from the downloaded file).
    """
    if simulate:
        log("SIMULATE MODE — not opening g:Profiler website (writing placeholder).")
        with open(out_csv, "w", encoding="utf-8") as fh:
            fh.write("source,term_name,term_id,adjusted_p_value,negative_log10_of_adjusted_p_value,"
                     "term_size,query_size,intersection_size,effective_domain_size,intersections\n")
        return 0

    try:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
    except ImportError:
        raise RuntimeError("Selenium not installed. Run:  pip install selenium  (and install Google Chrome)")

    genes = _read_genes_from_list(genes)
    headless = bool(cfg.get("headless", False))
    download_dir = os.path.dirname(out_csv)
    os.makedirs(download_dir, exist_ok=True)

    log(f"opening g:Profiler website · {len(genes)} genes · headless={headless}")
    driver = _make_driver(download_dir, headless)
    try:
        driver.get(URL)
        wait = WebDriverWait(driver, 40)

        # paste genes
        textarea = wait.until(EC.presence_of_element_located((By.TAG_NAME, "textarea")))
        textarea.clear()
        textarea.send_keys("\n".join(genes))

        # options: ONLY ordered query
        _set_checkbox(driver, "Ordered query", True)
        _set_checkbox(driver, "Highlight driver terms", False)
        _set_checkbox(driver, "Run as multiquery", False)
        log("options: Ordered query=ON · Highlight driver terms=OFF · Run as multiquery=OFF")

        # run query
        _click_first(driver, ["//button[normalize-space()='Run query']",
                              "//*[normalize-space(text())='Run query']",
                              "//input[@value='Run query']"])
        log("Run query clicked; waiting for results …")
        time.sleep(10)

        # open Detailed Results, click CSV
        _click_first(driver, ["//*[normalize-space(text())='Detailed Results']",
                              "//*[contains(normalize-space(.),'Detailed Results')]"])
        time.sleep(3)
        before = set(glob.glob(os.path.join(download_dir, "*.csv")))
        clicked = _click_first(driver, ["//button[normalize-space()='CSV']",
                                        "//a[normalize-space()='CSV']",
                                        "//*[normalize-space(text())='CSV']",
                                        "//*[contains(@title,'CSV')]"])
        if not clicked:
            raise RuntimeError("could not find the CSV download button on the results page")
        log("CSV download clicked; waiting for file …")

        got = _wait_download(download_dir, before)
        if not got:
            raise RuntimeError("CSV did not download within timeout")

        if os.path.exists(out_csv):
            os.remove(out_csv)
        shutil.move(got, out_csv)
        log(f"downloaded website CSV -> {out_csv}")

        # best-effort term count (rows minus header)
        try:
            with open(out_csv, encoding="utf-8", errors="ignore") as fh:
                n = max(0, sum(1 for _ in fh) - 1)
        except Exception:
            n = 0
        return n
    finally:
        driver.quit()
