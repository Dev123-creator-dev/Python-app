"""pipeline/config.py — load config_uat.yaml or config_prod.yaml (no hardcoded paths)."""
import os
import yaml

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(env="UAT"):
    fn = "config_uat.yaml" if env.upper() == "UAT" else "config_prod.yaml"
    path = os.path.join(BASE, "config", fn)
    with open(path, encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    cfg["_config_file"] = path
    cfg["_base"] = BASE
    return cfg


def resolve(cfg, rel):
    """Resolve a path from config relative to the project base (so UAT relative paths work)."""
    if not rel:
        return rel
    return rel if os.path.isabs(rel) else os.path.normpath(os.path.join(cfg["_base"], rel))
