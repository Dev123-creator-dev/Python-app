"""
pipeline/gprofiler_selenium.py — drive the g:Profiler WEBSITE (not the API)
and download the real CSV (gene names in the intersections column).

Steps performed (matches the SOP):
  - open https://biit.cs.ut.ee/gprofiler/gost
  - paste genes
  - Organism: Homo sapiens (default)
  - CHECK Ordered query ; UNCHECK Highlight driver terms + Run as multiquery
  - Run query -> Detailed Results tab -> click CSV -> save file

Requires: selenium (pip install selenium) and Google Chrome.
"""

import os
import glob
import time
import shutil

URL = "https://biit.cs.ut.ee/gprofiler/gost"


def _make_driver(download_dir, headless=True, log=print):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    os.makedirs(download_dir, exist_ok=True)
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--start-maximized")
    opts.add_argument("--ignore-certificate-errors")
    opts.add_argument("--no-sandbox")
    opts.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })
    driver = webdriver.Chrome(options=opts)
    try:
        driver.execute_cdp_cmd("Page.setDownloadBehavior",
                               {"behavior": "allow", "downloadPath": download_dir})
    except Exception:
        pass
    return driver


def _set_checkbox(driver, label_text, want_checked):
    from selenium.webdriver.common.by import By
    try:
        boxes = driver.find_elements(
            By.XPATH,
            f"//label[contains(normalize-space(.), '{label_text}')]//input[@type='checkbox'] | "
            f"//*[contains(normalize-space(.), '{label_text}')]/preceding-sibling::input[@type='checkbox'][1] | "
            f"//input[@type='checkbox'][following-sibling::*[contains(normalize-space(.), '{label_text}')]]"
        )
        for b in boxes:
            if b.is_selected() != want_checked:
                driver.execute_script("arguments[0].click();", b)
            return True
    except Exception:
        pass
    return False


def _click_first(driver, xpaths, timeout=15):
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    for xp in xpaths:
        try:
            el = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, xp)))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
            time.sleep(0.5)
            driver.execute_script("arguments[0].click();", el)
            return True
        except Exception:
            continue
    return False


def _wait_download(download_dir, before, timeout=120):
    end = time.time() + timeout
    while time.time() < end:
        files = set(glob.glob(os.path.join(download_dir, "*.csv"))) - before
        partial = glob.glob(os.path.join(download_dir, "*.crdownload"))
        if files and not partial:
            return max(files, key=os.path.getctime)
        time.sleep(1)
    return None


def run(genes, out_csv, headless=True, log=print):
    """Query the g:Profiler website for one gene list; save the CSV as out_csv.
    Returns the number of data rows written (approx: lines - 1), or raises on failure."""
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    download_dir = os.path.dirname(out_csv) or "."
    genes = [str(g).strip() for g in genes if str(g).strip()]
    log(f"opening g:Profiler website · {len(genes)} genes (headless={headless})")
    driver = _make_driver(download_dir, headless=headless, log=log)
    try:
        driver.get(URL)
        wait = WebDriverWait(driver, 40)

        # paste genes
        textarea = wait.until(EC.presence_of_element_located((By.TAG_NAME, "textarea")))
        textarea.clear()
        textarea.send_keys("\n".join(genes))

        # options: ONLY Ordered query
        _set_checkbox(driver, "Ordered query", True)
        _set_checkbox(driver, "Highlight driver terms", False)
        _set_checkbox(driver, "Run as multiquery", False)
        log("options: Ordered query=ON · Highlight driver terms=OFF · Run as multiquery=OFF")

        # Run query
        if not _click_first(driver, ["//button[normalize-space()='Run query']",
                                     "//*[normalize-space(text())='Run query']",
                                     "//input[@value='Run query']"]):
            raise RuntimeError("could not click 'Run query'")
        log("Run query clicked; waiting for results …")
        time.sleep(10)

        # Detailed Results tab
        _click_first(driver, ["//*[normalize-space(text())='Detailed Results']",
                              "//*[contains(normalize-space(.),'Detailed Results')]"])
        time.sleep(3)

        # CSV download
        before = set(glob.glob(os.path.join(download_dir, "*.csv")))
        clicked = _click_first(driver, ["//button[normalize-space()='CSV']",
                                        "//a[normalize-space()='CSV']",
                                        "//*[normalize-space(text())='CSV']",
                                        "//*[contains(@title,'CSV')]"])
        if not clicked:
            raise RuntimeError("could not find the CSV download button on the results page")

        got = _wait_download(download_dir, before)
        if not got:
            raise RuntimeError("CSV did not download within the timeout")

        if os.path.exists(out_csv):
            os.remove(out_csv)
        shutil.move(got, out_csv)
        log(f"downloaded website CSV -> {out_csv}")

        # count rows (minus header) for the log
        try:
            with open(out_csv, encoding="utf-8", errors="ignore") as fh:
                n = max(0, sum(1 for _ in fh) - 1)
        except Exception:
            n = 0
        return n
    finally:
        driver.quit()
