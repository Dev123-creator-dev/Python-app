"""
pipeline/gprofiler_selenium.py — drive the g:Profiler WEBSITE and download the real CSV.

Steps (matches the SOP):
  - open https://biit.cs.ut.ee/gprofiler/gost
  - paste genes ; Organism: Homo sapiens (default)
  - CHECK Ordered query ; UNCHECK Highlight driver terms + Run as multiquery
  - Run query -> Detailed Results tab -> click CSV -> save file

Requires: selenium (pip install selenium) and Google Chrome.
Robust Chrome startup (fixes 'DevToolsActivePort file doesn't exist').
"""

import os
import glob
import time
import shutil
import socket
import tempfile

URL = "https://biit.cs.ut.ee/gprofiler/gost"


def _free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _make_driver(download_dir, headless=True, log=print):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    os.makedirs(download_dir, exist_ok=True)
    # a fresh, unique profile dir every run avoids "user data dir in use" + DevTools races
    profile_dir = tempfile.mkdtemp(prefix="onco_chrome_")
    port = _free_port()

    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument(f"--user-data-dir={profile_dir}")
    opts.add_argument(f"--remote-debugging-port={port}")   # FIXED port, not 0
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--disable-extensions")
    opts.add_argument("--no-first-run")
    opts.add_argument("--no-default-browser-check")
    opts.add_argument("--disable-features=ChromeWhatsNewUI")
    opts.add_argument("--window-size=1400,1000")
    opts.add_argument("--ignore-certificate-errors")
    opts.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })

    try:
        driver = webdriver.Chrome(options=opts)
    except Exception as e:
        raise RuntimeError(
            "Chrome failed to start. Make sure Google Chrome is installed and up to date. "
            "Try updating Chrome (chrome://settings/help). Original error: " + str(e))

    try:
        driver.execute_cdp_cmd("Page.setDownloadBehavior",
                               {"behavior": "allow", "downloadPath": download_dir})
    except Exception:
        pass
    driver._onco_profile_dir = profile_dir   # remember so we can clean up
    return driver


def _set_checkbox(driver, label_text, want_checked):
    from selenium.webdriver.common.by import By
    try:
        boxes = driver.find_elements(
            By.XPATH,
            f"//label[contains(normalize-space(.), '{label_text}')]//input[@type='checkbox'] | "
            f"//*[contains(normalize-space(.), '{label_text}')]/preceding-sibling::input[@type='checkbox'][1] | "
            f"//input[@type='checkbox'][following-sibling::*[contains(normalize-space(.), '{label_text}')]]"
        )
        for b in boxes:
            if b.is_selected() != want_checked:
                driver.execute_script("arguments[0].click();", b)
            return True
    except Exception:
        pass
    return False


def _click_first(driver, xpaths, timeout=15):
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    for xp in xpaths:
        try:
            el = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, xp)))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
            time.sleep(0.5)
            driver.execute_script("arguments[0].click();", el)
            return True
        except Exception:
            continue
    return False


def _wait_download(download_dir, before, timeout=120):
    end = time.time() + timeout
    while time.time() < end:
        files = set(glob.glob(os.path.join(download_dir, "*.csv"))) - before
        partial = glob.glob(os.path.join(download_dir, "*.crdownload"))
        if files and not partial:
            return max(files, key=os.path.getctime)
        time.sleep(1)
    return None


def run(genes, out_csv, headless=True, log=print):
    """Query the g:Profiler website for one gene list; save the CSV as out_csv.
    Returns number of data rows written (lines - 1)."""
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    download_dir = os.path.dirname(out_csv) or "."
    genes = [str(g).strip() for g in genes if str(g).strip()]
    log(f"opening g:Profiler website · {len(genes)} genes (headless={headless})")
    driver = _make_driver(download_dir, headless=headless, log=log)
    profile_dir = getattr(driver, "_onco_profile_dir", None)
    try:
        driver.get(URL)
        wait = WebDriverWait(driver, 40)

        textarea = wait.until(EC.presence_of_element_located((By.TAG_NAME, "textarea")))
        textarea.clear()
        textarea.send_keys("\n".join(genes))

        _set_checkbox(driver, "Ordered query", True)
        _set_checkbox(driver, "Highlight driver terms", False)
        _set_checkbox(driver, "Run as multiquery", False)
        log("options: Ordered query=ON · Highlight driver terms=OFF · Run as multiquery=OFF")

        if not _click_first(driver, ["//button[normalize-space()='Run query']",
                                     "//*[normalize-space(text())='Run query']",
                                     "//input[@value='Run query']"]):
            raise RuntimeError("could not click 'Run query'")
        log("Run query clicked; waiting for results …")
        time.sleep(10)

        _click_first(driver, ["//*[normalize-space(text())='Detailed Results']",
                              "//*[contains(normalize-space(.),'Detailed Results')]"])
        time.sleep(3)

        before = set(glob.glob(os.path.join(download_dir, "*.csv")))
        if not _click_first(driver, ["//button[normalize-space()='CSV']",
                                     "//a[normalize-space()='CSV']",
                                     "//*[normalize-space(text())='CSV']",
                                     "//*[contains(@title,'CSV')]"]):
            raise RuntimeError("could not find the CSV download button on the results page")

        got = _wait_download(download_dir, before)
        if not got:
            raise RuntimeError("CSV did not download within the timeout")

        if os.path.exists(out_csv):
            os.remove(out_csv)
        shutil.move(got, out_csv)
        log(f"downloaded website CSV -> {out_csv}")

        try:
            with open(out_csv, encoding="utf-8", errors="ignore") as fh:
                n = max(0, sum(1 for _ in fh) - 1)
        except Exception:
            n = 0
        return n
    finally:
        try:
            driver.quit()
        except Exception:
            pass
        if profile_dir and os.path.isdir(profile_dir):
            shutil.rmtree(profile_dir, ignore_errors=True)
