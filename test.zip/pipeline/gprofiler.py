"""pipeline/gprofiler.py — 7.5.3 (sensitivity) & 7.5.4 (resistance) enrichment.

Sends the gene list to g:Profiler g:GOSt with:
  - Organism: Homo sapiens (hsapiens)
  - Ordered query: yes
and writes the results CSV in the SAME column format as the website download:
  source, term_name, term_id, adjusted_p_value,
  negative_log10_of_adjusted_p_value, term_size, query_size,
  intersection_size, effective_domain_size, intersections
"""
import csv
import math


# exact column order of the g:Profiler website CSV download
CSV_COLUMNS = [
    "source", "term_name", "term_id", "adjusted_p_value",
    "negative_log10_of_adjusted_p_value", "term_size", "query_size",
    "intersection_size", "effective_domain_size", "intersections",
]


def _clean_genes(genes):
    """Remove blanks, duplicates, quotes and stray whitespace; keep order."""
    seen, out = set(), []
    for g in genes:
        g = str(g).strip().strip('"').strip("'").strip()
        if g and g.lower() != "nan" and g not in seen:
            seen.add(g)
            out.append(g)
    return out


def _query(cfg, genes, all_results=False, log=None):
    import requests
    genes = _clean_genes(genes)
    payload = {
        "organism": cfg.get("organism", "hsapiens"),   # Homo sapiens
        "query": genes,
        "ordered": bool(cfg.get("ordered", True)),      # Ordered query
        "all_results": all_results,                     # "All results" fallback
        "no_evidences": False,                          # need intersections for the CSV
    }
    if log:
        log(f"POST {cfg['api_url']} · {len(genes)} genes · organism={payload['organism']} · ordered={payload['ordered']} · all_results={all_results}")
    verify = cfg.get("verify_ssl", True)
    if verify is False:
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass
    r = requests.post(cfg["api_url"], json=payload, timeout=90, verify=verify)
    if log:
        log(f"g:Profiler responded: HTTP {r.status_code}")
        if r.status_code >= 400:
            log(f"g:Profiler said: {r.text[:400]}")
    r.raise_for_status()
    data = r.json()
    return data.get("result", []), data.get("meta", {})


def _row_to_csv(row, meta):
    """Map one API result row to the website CSV columns."""
    p = row.get("p_value", "")
    try:
        neg_log = round(-math.log10(p), 6) if p and float(p) > 0 else ""
    except (ValueError, TypeError):
        neg_log = ""
    inter = row.get("intersections", [])
    # intersections can be a list of gene lists, or already gene names
    if inter and isinstance(inter[0], list):
        genes = [g for sub in inter for g in sub]
    else:
        genes = inter
    return {
        "source": row.get("source", ""),
        "term_name": row.get("name", ""),
        "term_id": row.get("native", ""),
        "adjusted_p_value": p,
        "negative_log10_of_adjusted_p_value": neg_log,
        "term_size": row.get("term_size", ""),
        "query_size": row.get("query_size", ""),
        "intersection_size": row.get("intersection_size", ""),
        "effective_domain_size": row.get("effective_domain_size", ""),
        "intersections": ",".join(str(g) for g in genes),
    }


def _write(path, rows, meta):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow(_row_to_csv(r, meta))


def run(cfg, genes, out_csv, highlight=True, simulate=False, log=print):
    """Query g:Profiler for one gene list, with the All-results fallback. Returns term count."""
    if simulate:
        log("SIMULATE MODE — not contacting g:Profiler (fake demo rows).")
        demo = [{"source": "GO:BP", "name": f"demo pathway {i}", "native": f"GO:00000{i}",
                 "p_value": 1e-3 / (i + 1), "term_size": 40 + i, "query_size": 60,
                 "intersection_size": 9 - (i % 5), "effective_domain_size": 20000,
                 "intersections": [["GENE1", "GENE2"]]} for i in range(6)]
        _write(out_csv, demo, {})
        return len(demo)
    log("LIVE MODE — contacting the real g:Profiler backend …")
    res, meta = _query(cfg, genes, all_results=False, log=log)
    if not res:
        log("no significant terms — retrying with All results (all_results=true)")
        res, meta = _query(cfg, genes, all_results=True, log=log)
    _write(out_csv, res, meta)
    log(f"wrote {len(res)} terms to {out_csv}")
    return len(res)
