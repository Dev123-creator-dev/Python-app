"""pipeline/report.py — 7.5.5 report: Table 3 (R1:W61) + top-10 sensitivity/resistance summaries."""
import os


def build_report(out_path, table3_rows, top10_sensitive, top10_resistant, compound, template_path=""):
    """Create the report .docx. Uses python-docx; falls back to .txt if unavailable."""
    try:
        from docx import Document
    except ImportError:
        return _fallback_txt(out_path, table3_rows, top10_sensitive, top10_resistant, compound)

    doc = Document(template_path) if template_path and os.path.exists(template_path) else Document()
    doc.add_heading(f"OncoPanel Genomics Report — {compound}", level=1)

    doc.add_heading("Summary — Top 10 genes associated with sensitivity (7.5.5.2)", level=2)
    doc.add_paragraph(", ".join(top10_sensitive))
    doc.add_heading("Summary — Top 10 genes associated with resistance (7.5.5.3)", level=2)
    doc.add_paragraph(", ".join(top10_resistant))

    doc.add_heading("Table 3 — DiffEx (7.5.5.1)", level=2)
    if table3_rows:
        t = doc.add_table(rows=1, cols=len(table3_rows[0]))
        t.style = "Light Grid Accent 1"
        for j, h in enumerate(table3_rows[0]):
            t.rows[0].cells[j].text = str(h)
        for row in table3_rows[1:]:
            cells = t.add_row().cells
            for j, v in enumerate(row):
                cells[j].text = str(v)
    doc.save(out_path)
    return out_path


def _fallback_txt(out_path, table3_rows, s10, r10, compound):
    txt = out_path.rsplit(".", 1)[0] + ".txt"
    with open(txt, "w", encoding="utf-8") as fh:
        fh.write(f"OncoPanel Report — {compound}\n\n")
        fh.write("Top 10 sensitivity: " + ", ".join(s10) + "\n")
        fh.write("Top 10 resistance:  " + ", ".join(r10) + "\n\n")
        fh.write("Table 3 (DiffEx):\n")
        for row in table3_rows:
            fh.write("\t".join(str(x) for x in row) + "\n")
    return txt
