"""
check_gprofiler.py — quick test: is this machine connecting to the g:Profiler backend?

Run:  python check_gprofiler.py
"""
import sys

URL = "https://biit.cs.ut.ee/gprofiler/api/gost/profile/"
TEST_GENES = ["TP53", "EGFR", "BRCA1", "MYC", "KRAS"]

print("Testing connection to g:Profiler backend ...")
print("URL:", URL)

try:
    import requests
except ImportError:
    print("FAILED: 'requests' not installed. Run:  pip install requests")
    sys.exit(1)

try:
    r = requests.post(URL, json={"organism": "hsapiens", "query": TEST_GENES,
                                 "ordered": True, "no_evidences": True}, timeout=30)
    print("HTTP status:", r.status_code)
    r.raise_for_status()
    result = r.json().get("result", [])
    print(f"SUCCESS ✅  Connected to g:Profiler. Got {len(result)} enrichment terms for the test genes.")
    if result:
        top = result[0]
        print("   example term:", top.get("source"), top.get("native"), "-", top.get("name"))
    print("\nThe machine CAN reach g:Profiler. Set options.simulate: false to get real results.")
except requests.exceptions.ConnectionError as e:
    print("FAILED ❌  Cannot reach g:Profiler (network/firewall/proxy blocked).")
    print("   detail:", e)
except requests.exceptions.Timeout:
    print("FAILED ❌  Connection timed out (slow network or blocked).")
except Exception as e:
    print("FAILED ❌ ", type(e).__name__, "-", e)
