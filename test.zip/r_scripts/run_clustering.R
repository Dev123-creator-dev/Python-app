# run_clustering.R — STEP 7.4 wrapper.
# Drives the two shared scripts:
#   (1) eurofinsdiscovery_..._clustering_script  = the CALLER (sets working_directory,
#       client_data_fn, then sources + calls the function below)
#   (2) GenerateClusteringFile.R                 = the FUNCTION that does the clustering
#
# We reproduce the caller here so the VALIDATED GenerateClusteringFile.R stays untouched.
# Usage: Rscript run_clustering.R <client_data_fn> <working_directory>

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) { cat("[ERROR] usage: Rscript run_clustering.R <tab> <workdir>\n"); quit(status = 2) }

client_data_fn     <- args[1]
working_directory <<- args[2]   # global — GenerateClusteringFile() writes its CSVs here

clustering_src <- Sys.getenv("CLUSTERING_SRC",
  "K:/LabOperations/Oncopanel/QC support files/GenerateClusteringFile.R")

cat(sprintf("[INFO] client_data_fn = %s\n", client_data_fn))
cat(sprintf("[INFO] working_directory = %s\n", working_directory))
cat(sprintf("[INFO] sourcing %s\n", clustering_src))

suppressMessages(library(dplyr))
source(clustering_src)               # SCRIPT 2
GenerateClusteringFile(client_data_fn)   # produces "clustering data.csv" + "ranked compounds.csv"
cat("[OK] STEP 7.4 clustering completed\n")
quit(status = 0)
