# migrate_7_3.R  — STEP 7.3 file migration (separate R script, as required).
# Copies the manually-downloaded Diffex + Mutation files to the configured target
# (C drive in UAT, K drive in PROD). Validates existence, logs, returns status.
#
# Usage: Rscript migrate_7_3.R <diffex_path> <mutation_path> <target_dir>
# Exit code 0 = success, non-zero = failure (Python reads this).

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3) {
  cat("[ERROR] usage: Rscript migrate_7_3.R <diffex> <mutation> <target_dir>\n")
  quit(status = 2)
}
diffex <- args[1]; mutation <- args[2]; target <- args[3]

log <- function(level, msg) cat(sprintf("[%s] %s\n", level, msg))

# validate inputs
missing <- c()
if (!file.exists(diffex))   missing <- c(missing, diffex)
if (!file.exists(mutation)) missing <- c(missing, mutation)
if (length(missing) > 0) {
  for (m in missing) log("ERROR", paste("input file not found:", m))
  quit(status = 3)
}

# ensure target dir exists
if (!dir.exists(target)) {
  dir.create(target, recursive = TRUE, showWarnings = FALSE)
  log("INFO", paste("created target dir:", target))
}

copy_one <- function(src) {
  dst <- file.path(target, basename(src))
  ok <- file.copy(src, dst, overwrite = TRUE)
  if (!ok) { log("ERROR", paste("copy failed:", src)); quit(status = 4) }
  log("OK", paste("copied", basename(src), "->", target))
  dst
}

log("INFO", "STEP 7.3 migration started")
copy_one(diffex)
copy_one(mutation)
log("OK", "STEP 7.3 migration completed")
quit(status = 0)
