"""pipeline/gprofiler.py — 7.5.3 (sensitivity) & 7.5.4 (resistance) enrichment."""
import csv


def _query(cfg, genes, all_results=False, highlight=True, log=None):
    import requests
    payload = {
        "organism": cfg.get("organism", "hsapiens"),
        "query": genes,
        "ordered": bool(cfg.get("ordered", True)),   # 7.5.3.4 / 7.5.4.4 "Ordered query"
        "all_results": all_results,                    # 7.5.3.5.1 "All results" fallback
        "highlight": highlight,                        # 7.5.4.4 uncheck "Highlight driver terms"
        "no_evidences": True,
    }
    if log:
        log(f"POST {cfg['api_url']} · {len(genes)} genes · ordered={payload['ordered']} · all_results={all_results}")
    r = requests.post(cfg["api_url"], json=payload, timeout=60)
    if log:
        log(f"g:Profiler responded: HTTP {r.status_code} from {r.url}")
    r.raise_for_status()
    return r.json().get("result", [])


def _write(path, rows):
    cols = ["source", "native", "name", "p_value", "term_size", "intersection_size"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])


def run(cfg, genes, out_csv, highlight=True, simulate=False, log=print):
    """Query g:Profiler for one gene list, with the All-results fallback. Returns term count."""
    if simulate:
        log("SIMULATE MODE — NOT contacting g:Profiler (fake demo rows). Set options.simulate: false for real results.")
        demo = [{"source": "GO:BP", "native": f"GO:00000{i}", "name": f"demo pathway {i}",
                 "p_value": round(1e-3 / (i + 1), 6), "term_size": 40 + i,
                 "intersection_size": 9 - (i % 5)} for i in range(6)]
        _write(out_csv, demo)
        return len(demo)
    log("LIVE MODE — contacting the real g:Profiler backend …")
    try:
        res = _query(cfg, genes, all_results=False, highlight=highlight, log=log)
    except Exception as exc:
        log(f"CONNECTION FAILED to g:Profiler: {exc}")
        raise
    if not res:
        log("no significant terms — retrying with All results (all_results=true)")
        res = _query(cfg, genes, all_results=True, highlight=highlight, log=log)
    _write(out_csv, res)
    log(f"wrote {len(res)} terms to {out_csv}")
    return len(res)
