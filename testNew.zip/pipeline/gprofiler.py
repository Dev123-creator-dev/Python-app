"""pipeline/gprofiler.py — 7.5.3 / 7.5.4 enrichment via the g:Profiler REST API.

No browser needed (works where corporate policy blocks Selenium).
Writes the CSV in the SAME column format as the website, and maps the
intersections column to GENE NAMES (not evidence codes).
"""
import csv
import math

CSV_COLUMNS = [
    "source", "term_name", "term_id", "adjusted_p_value",
    "negative_log10_of_adjusted_p_value", "term_size", "query_size",
    "intersection_size", "effective_domain_size", "intersections",
]


def _clean_genes(genes):
    seen, out = set(), []
    for g in genes:
        g = str(g).strip().strip('"').strip("'").strip()
        if g and g.lower() != "nan" and g not in seen:
            seen.add(g)
            out.append(g)
    return out


def _query(cfg, genes, all_results=False, log=None):
    import requests
    genes = _clean_genes(genes)
    payload = {
        "organism": cfg.get("organism", "hsapiens"),
        "query": genes,
        "ordered": bool(cfg.get("ordered", True)),
        "all_results": all_results,
        "no_evidences": False,
    }
    if log:
        log(f"POST {cfg['api_url']} · {len(genes)} genes · organism={payload['organism']} · ordered={payload['ordered']} · all_results={all_results}")
    verify = cfg.get("verify_ssl", True)
    if verify is False:
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass
    r = requests.post(cfg["api_url"], json=payload, timeout=90, verify=verify)
    if log:
        log(f"g:Profiler responded: HTTP {r.status_code}")
        if r.status_code >= 400:
            log(f"g:Profiler said: {r.text[:400]}")
    r.raise_for_status()
    data = r.json()
    return data.get("result", []), data.get("meta", {}), genes


def _query_gene_order(meta, sent_genes):
    """Return the ordered list of query gene names as g:Profiler indexed them.
    The 'intersections' arrays in each result align to this order."""
    try:
        qmeta = meta.get("genes_metadata", {}).get("query", {})
        # qmeta is usually {query_name: {"mapping": {GENE: [ids...]}, "ensgs":[...]}}
        # Fall back to the genes we sent (already the ordered query).
        for _, info in qmeta.items():
            mapping = info.get("mapping")
            if isinstance(mapping, dict) and mapping:
                return list(mapping.keys())
    except Exception:
        pass
    return sent_genes


def _row_to_csv(row, gene_order):
    p = row.get("p_value", "")
    try:
        neg_log = round(-math.log10(p), 6) if p and float(p) > 0 else ""
    except (ValueError, TypeError):
        neg_log = ""

    # Map the boolean/index 'intersections' to gene NAMES using the query order.
    inter = row.get("intersections") or []
    genes = []
    try:
        if inter and isinstance(inter[0], list):
            # list per query gene: non-empty sublist = that gene is in the term
            for i, sub in enumerate(inter):
                if sub and i < len(gene_order):
                    genes.append(gene_order[i])
        else:
            # flat list aligned to query order: truthy = present
            for i, flag in enumerate(inter):
                if flag and i < len(gene_order):
                    genes.append(gene_order[i])
    except Exception:
        genes = []

    return {
        "source": row.get("source", ""),
        "term_name": row.get("name", ""),
        "term_id": row.get("native", ""),
        "adjusted_p_value": p,
        "negative_log10_of_adjusted_p_value": neg_log,
        "term_size": row.get("term_size", ""),
        "query_size": row.get("query_size", ""),
        "intersection_size": row.get("intersection_size", ""),
        "effective_domain_size": row.get("effective_domain_size", ""),
        "intersections": ",".join(genes),
    }


def _write(path, rows, gene_order):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow(_row_to_csv(r, gene_order))


def run(cfg, genes, out_csv, highlight=True, simulate=False, log=print):
    if simulate:
        log("SIMULATE MODE — not contacting g:Profiler (fake demo rows).")
        demo = [{"source": "GO:BP", "name": f"demo pathway {i}", "native": f"GO:00000{i}",
                 "p_value": 1e-3 / (i + 1), "term_size": 40 + i, "query_size": 60,
                 "intersection_size": 2, "effective_domain_size": 20000,
                 "intersections": [[1], [], [1]]} for i in range(6)]
        _write(out_csv, demo, ["GENE1", "GENE2", "GENE3"])
        return len(demo)
    log("LIVE MODE — contacting the real g:Profiler backend …")
    res, meta, sent = _query(cfg, genes, all_results=False, log=log)
    if not res:
        log("no significant terms — retrying with All results (all_results=true)")
        res, meta, sent = _query(cfg, genes, all_results=True, log=log)
    gene_order = _query_gene_order(meta, sent)
    _write(out_csv, res, gene_order)
    log(f"wrote {len(res)} terms to {out_csv}")
    return len(res)
