"""app.py — Python UI: dashboard + log viewer + start/monitor runs.

Run:  pip install -r requirements.txt  &&  python app.py  ->  http://127.0.0.1:5000
"""
import os
import tempfile
from flask import Flask, request, jsonify, render_template

from pipeline import controller

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024


@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/runs", methods=["GET"])
def list_runs():
    return jsonify(controller.list_runs())


@app.route("/api/runs", methods=["POST"])
def create_run():
    env = request.form.get("environment", "UAT")
    params = {"compound": (request.form.get("compound") or "run").strip() or "run"}
    files = {}
    tmp = tempfile.mkdtemp()
    for field in ("diffex", "mutation", "tab"):
        f = request.files.get(field)
        if f and f.filename:
            path = os.path.join(tmp, os.path.basename(f.filename))
            f.save(path)
            files[field] = path
    run = controller.create_run(env, params, files)
    controller.start_run(run)
    return jsonify({"run_id": run["run_id"]})


@app.route("/api/runs/<rid>")
def run_status(rid):
    run = controller.get_run(rid)
    if not run:
        return jsonify({"error": "not found"}), 404
    with controller._lock:
        return jsonify({
            "run_id": run["run_id"], "environment": run["environment"],
            "overall_status": run["overall_status"], "started": run["started"],
            "ended": run["ended"], "duration_sec": run["duration_sec"],
            "error": run["error"], "artifacts": run["artifacts"],
            "steps": run["steps"], "logs": run["logs"][-500:],
        })


@app.route("/api/runs/<rid>/logs")
def run_logs(rid):
    """Log viewer: return logs, optionally filtered to one step."""
    run = controller.get_run(rid)
    if not run:
        return jsonify({"error": "not found"}), 404
    step = request.args.get("step")
    with controller._lock:
        logs = run["logs"] if not step else [l for l in run["logs"] if l["step"] == step]
    return jsonify({"logs": logs})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, threaded=True)
