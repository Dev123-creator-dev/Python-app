"""
pipeline/controller.py — orchestrates the whole run.

Steps (each isolated, continue only on success):
  7.3   migrate Diffex+Mutation to configured location (R script)
  7.4   run clustering (R: caller + GenerateClusteringFile)
  7.5.1 load template + Diffex, validate required columns
  7.5.2 populate template (Table 3 + Mutation/Hotspot tables) — reproduces Excel logic
  7.5.3 g:Profiler — sensitivity (Top-60, ordered)
  7.5.4 g:Profiler — resistance (Top-60, ordered, highlight off)
  7.5.5 build report (Table 3 + Top-10 summaries)

Every run: its own folder with input/ output/ reports/ logs/ status.json.
"""

import os
import json
import time
import shutil
import datetime
import threading
import subprocess

from . import config as cfgmod
from . import excel_logic, gprofiler, report

STEPS = ["7.3", "7.4", "7.5.1", "7.5.2", "7.5.3", "7.5.4", "7.5.5"]

_lock = threading.Lock()
_RUNS = {}   # run_id -> run dict (in-memory mirror of status.json)


# --------------------------------------------------------------------------- utils
def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _run_id():
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


class RunLog:
    """Writes to logs/pipeline.log and per-step logs/<step>.log, and to memory for the UI."""
    def __init__(self, run):
        self.run = run
        self.logs_dir = os.path.join(run["dir"], "logs")
        self.main = open(os.path.join(self.logs_dir, "pipeline.log"), "a", encoding="utf-8")

    def __call__(self, msg, level="INFO", step="pipeline"):
        line = f"{_now()}  {level:<5} {step:<7} {msg}"
        self.main.write(line + "\n"); self.main.flush()
        with open(os.path.join(self.logs_dir, f"{step}.log"), "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        with _lock:
            self.run["logs"].append({"ts": _now(), "level": level, "step": step, "msg": msg})


def _save_status(run):
    data = {k: run[k] for k in ("run_id", "environment", "overall_status", "started",
                                "ended", "duration_sec", "steps", "error", "artifacts", "params")}
    with open(os.path.join(run["dir"], "status.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def _set_step(run, step, status, detail=""):
    with _lock:
        s = run["steps"][step]
        s["status"] = status
        if status == "RUNNING" and not s["started"]:
            s["started"] = _now()
        if status in ("COMPLETED", "FAILED"):
            s["ended"] = _now()
        if detail:
            s["detail"] = detail
    _save_status(run)


# --------------------------------------------------------------------------- run store
def create_run(env, params, files):
    cfg = cfgmod.load(env)
    runs_base = cfgmod.resolve(cfg, cfg["paths"]["runs_path"])
    rid = _run_id()
    run_dir = os.path.join(runs_base, rid)
    for sub in ("input", "output", "reports", "logs"):
        os.makedirs(os.path.join(run_dir, sub), exist_ok=True)

    run = {
        "run_id": rid, "environment": cfg["environment"], "dir": run_dir,
        "overall_status": "NOT STARTED", "started": None, "ended": None, "duration_sec": None,
        "error": None, "artifacts": [], "params": params, "logs": [],
        "steps": {s: {"status": "PENDING", "started": None, "ended": None, "detail": ""} for s in STEPS},
        "_cfg": cfg,
    }
    # stash uploaded input files
    for key, src in (files or {}).items():
        if src and os.path.exists(src):
            dst = os.path.join(run_dir, "input", os.path.basename(src))
            shutil.copy2(src, dst)
            run["params"][key] = dst
    with _lock:
        _RUNS[rid] = run
    _save_status(run)
    return run


def get_run(rid):
    with _lock:
        return _RUNS.get(rid)


def list_runs():
    with _lock:
        return [{"run_id": r["run_id"], "environment": r["environment"],
                 "overall_status": r["overall_status"], "started": r["started"]}
                for r in sorted(_RUNS.values(), key=lambda x: x["run_id"], reverse=True)]


# --------------------------------------------------------------------------- steps
def _validate_files(run, log):
    p = run["params"]
    checks = [("Diffex file", p.get("diffex")), ("Mutation file", p.get("mutation"))]
    missing = [n for n, v in checks if not (v and os.path.exists(v))]
    for n, v in checks:
        log(f"{'✓' if (v and os.path.exists(v)) else '✗'} {n} {'found' if (v and os.path.exists(v)) else 'NOT found'}",
            level="OK" if (v and os.path.exists(v)) else "ERROR", step="7.3")
    if missing:
        raise RuntimeError(f"cannot start — missing: {', '.join(missing)}")


def _step_73(run, cfg, log, simulate):
    p, paths = run["params"], cfg["paths"]
    target = cfgmod.resolve(cfg, paths["migration_target"])
    os.makedirs(target, exist_ok=True)
    if simulate:
        for k in ("diffex", "mutation"):
            shutil.copy2(p[k], os.path.join(target, os.path.basename(p[k])))
            log(f"[simulate] copied {os.path.basename(p[k])} -> {target}", level="OK", step="7.3")
        return
    cmd = [paths["rscript_exe"], cfgmod.resolve(cfg, paths["migrate_script"]),
           p["diffex"], p["mutation"], target]
    _rscript(run, cmd, cfg, log, step="7.3")


def _step_74(run, cfg, log, simulate):
    p, paths = run["params"], cfg["paths"]
    out = os.path.join(run["dir"], "output")
    tab = p.get("tab") or p.get("diffex")   # clustering runs on the assay .tab
    if simulate:
        open(os.path.join(out, "clustering data.csv"), "w").write("Compound,cellLineName,EC50_Nrank\n")
        open(os.path.join(out, "ranked compounds.csv"), "w").write("Compound,Rank\n")
        log('[1] "Complete."', level="R", step="7.4")
        return
    env = dict(os.environ, CLUSTERING_SRC=cfgmod.resolve(cfg, paths["clustering_src"]))
    cmd = [paths["rscript_exe"], cfgmod.resolve(cfg, paths["clustering_wrapper"]), tab, out]
    _rscript(run, cmd, cfg, log, step="7.4", env=env)


def _rscript(run, cmd, cfg, log, step, env=None):
    log(" ".join(str(c) for c in cmd), step=step)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, env=env)
    except FileNotFoundError:
        raise RuntimeError("Rscript not found — set paths.rscript_exe in config, or options.simulate: true")
    # save R stdout/stderr into the run's log folder
    with open(os.path.join(run["dir"], "logs", f"{step}_rscript.log"), "w", encoding="utf-8") as fh:
        fh.write((proc.stdout or "") + "\n---STDERR---\n" + (proc.stderr or ""))
    for ln in (proc.stdout or "").splitlines():
        log(ln, level="R", step=step)
    if proc.returncode != 0:
        for ln in (proc.stderr or "").splitlines()[-8:]:
            log(ln, level="ERROR", step=step)
        raise RuntimeError(f"{step} R script exited with code {proc.returncode}")


def _step_75(run, cfg, log, simulate):
    p, paths, gp = run["params"], cfg["paths"], cfg["gprofiler"]
    out, reps = os.path.join(run["dir"], "output"), os.path.join(run["dir"], "reports")

    # 7.5.1 — load + validate
    _set_step(run, "7.5.1", "RUNNING")
    header, rows = excel_logic.load_diffex(p["diffex"])
    excel_logic.validate_diffex(header)
    log(f"✓ Diffex loaded ({len(rows)} rows) · required columns validated", level="OK", step="7.5.1")
    mut_header, mut_rows = (None, None)
    if p.get("mutation") and os.path.exists(p["mutation"]):
        try:
            mut_header, mut_rows = excel_logic.load_mutation(p["mutation"])
        except Exception:
            mut_rows = None
    _set_step(run, "7.5.1", "COMPLETED")

    # 7.5.2 — populate template (Table 3 + Mutation/Hotspot); reproduces Excel logic
    _set_step(run, "7.5.2", "RUNNING")
    template = cfgmod.resolve(cfg, paths["mutations_hotspots_template"])
    populated = os.path.join(out, "Mutations_and_Hotspots_POPULATED.xlsx")
    if template and os.path.exists(template):
        excel_logic.populate_template(template, header, rows, mut_rows, populated)
        run["artifacts"].append("output/Mutations_and_Hotspots_POPULATED.xlsx")
        log("✓ template populated (Table 3 A-P + Mutation/Hotspot tables)", level="OK", step="7.5.2")
    else:
        log("template not found — computing gene lists in-memory only", level="WARN", step="7.5.2")
    lists = excel_logic.compute_gene_lists(header, rows, gp["top_n"], gp["report_top_n"], gp["sensitive_max_fc"])
    open(os.path.join(out, "top60_sensitive.txt"), "w").write("\n".join(lists["top60_sensitive"]))
    open(os.path.join(out, "top60_resistant.txt"), "w").write("\n".join(lists["top60_resistant"]))
    log(f"gene lists: {lists['n_sensitive']} sensitive / {lists['n_resistant']} resistant", level="OK", step="7.5.2")
    _set_step(run, "7.5.2", "COMPLETED")

    # 7.5.3 — g:Profiler sensitivity
    _set_step(run, "7.5.3", "RUNNING")
    n_s = gprofiler.run(gp, lists["top60_sensitive"], os.path.join(reps, "sensitivity.csv"),
                        highlight=True, simulate=simulate, log=lambda m: log(m, step="7.5.3"))
    run["artifacts"].append("reports/sensitivity.csv")
    log(f"✓ sensitivity enrichment: {n_s} terms", level="OK", step="7.5.3")
    _set_step(run, "7.5.3", "COMPLETED")

    # 7.5.4 — g:Profiler resistance (highlight off)
    _set_step(run, "7.5.4", "RUNNING")
    n_r = gprofiler.run(gp, lists["top60_resistant"], os.path.join(reps, "resistance.csv"),
                        highlight=False, simulate=simulate, log=lambda m: log(m, step="7.5.4"))
    run["artifacts"].append("reports/resistance.csv")
    log(f"✓ resistance enrichment: {n_r} terms", level="OK", step="7.5.4")
    _set_step(run, "7.5.4", "COMPLETED")

    # 7.5.5 — report
    _set_step(run, "7.5.5", "RUNNING")
    table3 = excel_logic.report_table3(header, rows, n=60)
    rpath = report.build_report(os.path.join(reps, "OncoPanel_Report.docx"), table3,
                                lists["top10_sensitive"], lists["top10_resistant"],
                                run["params"].get("compound", "run"),
                                cfgmod.resolve(cfg, paths.get("report_template", "")))
    run["artifacts"].append("reports/" + os.path.basename(rpath))
    log(f"✓ report generated: {os.path.basename(rpath)}", level="OK", step="7.5.5")
    _set_step(run, "7.5.5", "COMPLETED")


# --------------------------------------------------------------------------- orchestrate
def _execute(run):
    cfg = run["_cfg"]
    simulate = cfg.get("options", {}).get("simulate", False)
    log = RunLog(run)
    run["overall_status"], run["started"] = "RUNNING", _now()
    _save_status(run)
    t0 = time.time()
    log(f"=== RUN {run['run_id']} ({run['environment']}) · simulate={simulate} ===")

    try:
        _validate_files(run, log)

        _set_step(run, "7.3", "RUNNING"); log("STEP 7.3 migrate started", step="7.3")
        _step_73(run, cfg, log, simulate); _set_step(run, "7.3", "COMPLETED")

        _set_step(run, "7.4", "RUNNING"); log("STEP 7.4 clustering started", step="7.4")
        _step_74(run, cfg, log, simulate); _set_step(run, "7.4", "COMPLETED")

        _step_75(run, cfg, log, simulate)   # handles 7.5.1..7.5.5

        run["overall_status"] = "COMPLETED"
        log("RUN COMPLETED SUCCESSFULLY", level="OK")
    except Exception as exc:
        # find the step currently running and mark it FAILED
        cur = next((s for s in STEPS if run["steps"][s]["status"] == "RUNNING"), None)
        if cur:
            _set_step(run, cur, "FAILED", detail=str(exc))
        run["error"] = f"{cur or 'pipeline'}: {exc}"
        run["overall_status"] = "FAILED" if run["steps"]["7.3"]["status"] != "COMPLETED" else "PARTIALLY COMPLETED"
        log(f"[ERROR] Step: {cur} | {exc}", level="ERROR", step=cur or "pipeline")
        log("RUN FAILED — run folder preserved for troubleshooting", level="ERROR")
    finally:
        run["ended"], run["duration_sec"] = _now(), round(time.time() - t0, 1)
        _save_status(run)


def start_run(run):
    threading.Thread(target=_execute, args=(run,), daemon=True).start()
