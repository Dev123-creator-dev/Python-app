# Onco Automation — Steps 7.3, 7.4, 7.5

A modular, config-driven Python + R application that automates the OncoPanel report
workflow. OncoPredictor is run manually; this app takes the downloaded files and runs
**7.3 → 7.4 → 7.5.1–7.5.5**, with a UI dashboard, per-run folders, logging, status, and
error handling. UAT runs on **C drive**, production on **K drive** — switched by config only.

## What it does (per run, isolated folder)
| Step | Action | Output |
|------|--------|--------|
| 7.3 | Migrate Diffex + Mutation to configured location (R script `migrate_7_3.R`) | files in `migration_target` |
| 7.4 | Clustering (R: caller + `GenerateClusteringFile.R`) | `clustering data.csv`, `ranked compounds.csv` |
| 7.5.1 | Load template + Diffex, validate required columns | — |
| 7.5.2 | Populate template (Table 3 + Mutation/Hotspot) — reproduces Excel logic | `Mutations_and_Hotspots_POPULATED.xlsx`, `top60_*.txt` |
| 7.5.3 | g:Profiler — sensitivity (Top-60, ordered) | `sensitivity.csv` |
| 7.5.4 | g:Profiler — resistance (Top-60, ordered, highlight off) | `resistance.csv` |
| 7.5.5 | Report (Table 3 R1:W61 + Top-10 summaries) | `OncoPanel_Report.docx` |

## Prerequisites
- Python 3.9+ (`pip install -r requirements.txt`)
- R with `dplyr`, and `Rscript` reachable (set full path in config for Windows)
- Reachable: the configured paths (C or K drive), the R support files, and `biit.cs.ut.ee` (g:Profiler)

## Run the UI
```bash
pip install -r requirements.txt
python app.py            #  http://127.0.0.1:5000
```
Pick **UAT**, choose the Diffex + Mutation files, press **Start run**, and watch the
7 steps update live. Use the **log viewer** tabs to see per-step logs; **run history** to revisit runs.

### Test with sample data (no R / no internet)
`config_uat.yaml` has `options.simulate: true`, so R and g:Profiler are faked while the
Excel/report logic runs for real. Sample inputs are in `sample_data/`.

## Configuration (no hardcoded paths)
Everything environment-specific lives in `config/config_uat.yaml` (C drive) and
`config/config_prod.yaml` (K drive). To go to production: select **PROD** in the UI (or
load `config_prod.yaml`) and set `options.simulate: false`. No Python/R changes needed.

## Run folder layout
```
runs/2026-08-11_14-11-26/
├── input/     original Diffex + Mutation
├── output/    populated template, clustering CSVs, gene lists
├── reports/   sensitivity.csv, resistance.csv, OncoPanel_Report.docx
├── logs/      pipeline.log + per-step logs (7.3.log … 7.5.5.log) + R stdout
└── status.json  run status, per-step status, timings, artifacts, error
```

## Project layout
```
onco_automation/
├── config/            config_uat.yaml · config_prod.yaml
├── r_scripts/         migrate_7_3.R (7.3) · run_clustering.R (7.4 wrapper)
├── pipeline/          config, controller, excel_logic, gprofiler, report
├── templates/         dashboard.html (UI)
├── templates_xlsx/    the real Mutations & Hotspots template
├── app.py             Flask UI + API
├── sample_data/       sample Diffex + Mutation for testing
└── requirements.txt
```

## Business logic preserved (from the template)
- Drug Response = `IF(FoldChange < 0, "Sensitive", "Resistant")`
- Sensitive pool = `FoldChange < 1`; Resistant pool = `FoldChange > 1` (in Diffex order)
- Top-60 → g:Profiler (7.5.3/7.5.4); Top-10 → report summary (7.5.5)
- The populated `.xlsx` keeps the template's own formulas, so opening it in Excel reproduces
  the exact original calculations.

## ⚠️ Flagged ambiguity (needs sign-off, not assumed)
Drug Response splits at `FC < 0` but the gene pools split at `FC < 1` / `> 1`. A gene with
`0 < FC < 1` would fall in the Sensitive pool yet be labelled Resistant. We preserve the
template's literal `< 1` / `> 1` for the gene lists and surface this for confirmation.

## Errors
Every step: validated before running, logged, shown in the UI, and on failure the step is
marked `FAILED`, the run stops (fail-fast), and the **run folder is preserved** for troubleshooting.
`status.json` and the per-step logs pinpoint where it failed.
